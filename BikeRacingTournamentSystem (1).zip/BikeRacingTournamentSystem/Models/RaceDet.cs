﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace BikeRacingTournamentSystem.Models
{
    public class RaceDet
    {
        //public string ID { get; set; }
        [Display(Name = "Race date ")]
        [Required(ErrorMessage = "Please Enter Race date.")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime Race_date { get; set; }
        [Display(Name = "Winning Price ")]
        [Required(ErrorMessage = "Please Enter Price.")]
        public string Price { get; set; }
        [Display(Name = "Location ")]
        [Required(ErrorMessage = "Please Enter Location.")]
        public string Location { get; set; }
        [Display(Name = "Race Detail ")]
        [Required(ErrorMessage = "Please Enter Race Detail.")]
        public string Race_Detail { get; set; }
    }
}