﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BikeRacingTournamentSystem.Models
{
    public class WinnerDetail
    {
        [Display(Name = "Winner Name ")] 
        public string WinnerName { get; set; } 
        public List<WinnerList> Winner { get; set; }
    }

    public class WinnerList
    {
        public string text { get; set; }
        public string value { get; set; }
    }
}