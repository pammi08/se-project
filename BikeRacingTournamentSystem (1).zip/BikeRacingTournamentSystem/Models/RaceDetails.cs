﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BikeRacingTournamentSystem.Models
{
    public class RaceDetails
    { 
        public string ID { get; set; }
        [Display(Name = "Race date ")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = "Please Enter Race date.")]
        public DateTime Race_date { get; set; }
        [Display(Name = "Winning Price ")]
        [Required(ErrorMessage = "Please Enter Price.")]
        public string Price { get; set; }
        [Display(Name = "Location ")]
        [Required(ErrorMessage = "Please Enter Location.")]
        public string Location { get; set; }
        [Display(Name = "Race Detail ")]
        [Required(ErrorMessage = "Please Enter Race Detail.")]
        public string Race_Detail { get; set; }
        public string Winner { get; set; }
        public string status { get; set; }
}
}