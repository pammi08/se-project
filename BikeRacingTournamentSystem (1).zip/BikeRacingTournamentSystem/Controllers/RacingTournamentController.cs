﻿using BikeRacingTournamentSystem.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace BikeRacingTournamentSystem.Controllers
{
    [Authorize]
    public class RacingTournamentController : Controller
    {
        string Connection = "server=localhost;uid=root;" + "database=DB_BIKE_RACING; SslMode = none";
        // GET: Login

        [AllowAnonymous]
        public ActionResult Login()
        {
            return View();
        }


        [HttpPost]
        [AllowAnonymous]
        public ActionResult Login(Login obj)
        {
            DataSet ds = new DataSet();
            using (MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(Connection))
            {
                MySql.Data.MySqlClient.MySqlDataAdapter da = new MySql.Data.MySqlClient.MySqlDataAdapter("select * from TBL_Racer_Details o where o.UserName= @UserName and o.Password= @Password", conn);
                da.SelectCommand.Parameters.AddWithValue("@UserName", obj.userName);
                da.SelectCommand.Parameters.AddWithValue("@Password", obj.password);
                da.Fill(ds);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    FormsAuthentication.SetAuthCookie(ds.Tables[0].Rows[0]["UserRoles"].ToString(), false);
                    Session["UserID"] = ds.Tables[0].Rows[0]["UserID"].ToString();
                    Session["UserRoles"] = ds.Tables[0].Rows[0]["UserRoles"].ToString();
                    return RedirectToAction("Index");
                }

            }
            return View();
        }

        [AllowAnonymous]
        public ActionResult UserRegistration()
        {
            return View();
        }


        [HttpPost]
        [AllowAnonymous]
        public ActionResult UserRegistration(RegistrationDetails obj)
        {
            int count = 0;
            using (MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(Connection))
            {
                MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand("select Count(*) from TBL_Racer_Details o where o.UserName = @UserName and o.Password = @Password", conn);
                cmd.Parameters.AddWithValue("@UserName", obj.Name);
                cmd.Parameters.AddWithValue("@Password", obj.Password);
                conn.Open();
                count = Convert.ToInt32(cmd.ExecuteScalar());
                conn.Close();
                if (count > 0)
                {
                    ViewBag.Message = "User Already Exist.";
                }
                else
                {
                    MySql.Data.MySqlClient.MySqlCommand cmd1 = new MySql.Data.MySqlClient.MySqlCommand("insert into TBL_Racer_Details(UserName,FirstName,LastName,Email,PhoneNO,Password,Age,UserRoles,Byke) values(@UserName,@FirstName,@LastName,@Email,@PhoneNO,@Password,@Age,@UserRoles,@Byke)", conn);
                    cmd1.Parameters.AddWithValue("@UserName", obj.Name);
                    cmd1.Parameters.AddWithValue("@FirstName", obj.FirstName);
                    cmd1.Parameters.AddWithValue("@LastName", obj.LastName);
                    cmd1.Parameters.AddWithValue("@Email", obj.Email);
                    cmd1.Parameters.AddWithValue("@PhoneNO", obj.Phone);
                    cmd1.Parameters.AddWithValue("@Password", obj.Password);
                    cmd1.Parameters.AddWithValue("@Age", obj.Age);
                    cmd1.Parameters.AddWithValue("@UserRoles", obj.Roles);
                    if (obj.Roles == "Racers")
                    {
                        cmd1.Parameters.AddWithValue("@Byke", obj.Bike);
                    }
                    else
                    {
                        cmd1.Parameters.AddWithValue("@Byke", "");
                    }
                    conn.Open();
                    count = cmd1.ExecuteNonQuery();
                    conn.Close();
                    if (count == 0)
                    {
                        ViewBag.Message = "Error While inserting Data.";
                    }
                    else
                    {
                        return RedirectToAction("Login", "RacingTournament");
                    }
                }
            }
            return View();
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult RacerDetails(string ID)
        {
            List<RegistrationDetails> lstDetails = new List<RegistrationDetails>();
            DataSet ds = new DataSet();
            using (MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(Connection))
            {
                MySql.Data.MySqlClient.MySqlDataAdapter da = new MySql.Data.MySqlClient.MySqlDataAdapter("SELECT D.* FROM tbl_race_participate_det P, TBL_Racer_Details D Where P.RaceId = " + ID + " AND P.RacerId = D.UserID AND D.UserRoles = 'Racers'", conn);
                da.Fill(ds);

                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    RegistrationDetails RegistrationDetails = new RegistrationDetails();
                    RegistrationDetails.UserID = dr["UserID"].ToString();
                    RegistrationDetails.Name = dr["UserName"].ToString();
                    RegistrationDetails.FirstName = dr["FirstName"].ToString();
                    RegistrationDetails.LastName = dr["LastName"].ToString();
                    RegistrationDetails.Email = dr["Email"].ToString();
                    RegistrationDetails.Phone = dr["PhoneNO"].ToString();
                    RegistrationDetails.Age = dr["Age"].ToString();
                    RegistrationDetails.Bike = dr["BYKE"].ToString();
                    lstDetails.Add(RegistrationDetails);
                }
            }
            return View(lstDetails);
        }

        [AllowAnonymous]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }

        public ActionResult AddRace()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddRace(RaceDet RaceDetails)
        {
            int count = 0;
            string Out = "";
            if (ModelState.IsValid)
            {

                using (MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(Connection))
                {
                    MySql.Data.MySqlClient.MySqlCommand cmd1 = new MySql.Data.MySqlClient.MySqlCommand("insert into tbl_RACE_DETAIL(Race_date,Price,Location,Race_Detail) Values(@Race_date,@Price,@Location,@Race_Detail)", conn);
                    cmd1.Parameters.AddWithValue("@Race_date", RaceDetails.Race_date);
                    cmd1.Parameters.AddWithValue("@Price", RaceDetails.Price);
                    cmd1.Parameters.AddWithValue("@Location", RaceDetails.Location);
                    cmd1.Parameters.AddWithValue("@Race_Detail", RaceDetails.Race_Detail);
                    conn.Open();
                    count = cmd1.ExecuteNonQuery();
                    conn.Close();
                    if (count == 0)
                    {
                        Out = "Error While inserting Data.";
                    }
                    else
                    {
                        Out = "Y";
                    }
                }
                return View("Index");
            }
            return View();
        }
        public ActionResult RaceDetails()
        {
            List<RaceDetails> lstRaceDetails = new List<RaceDetails>();
            DataSet ds = new DataSet();
            using (MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(Connection))
            {
                //MySql.Data.MySqlClient.MySqlDataAdapter da = new MySql.Data.MySqlClient.MySqlDataAdapter("SELECT ID,Race_date,Race_Detail,Price,Location,Race_Detail,Winner,(Select 'Y' from tbl_race_detail) FROM  tbl_race_detail Order By Race_date", conn);
                MySql.Data.MySqlClient.MySqlDataAdapter da = new MySql.Data.MySqlClient.MySqlDataAdapter("SELECT U.ID,U.Race_date,U.Race_Detail,U.Price,U.Location,U.Race_Detail,U.Winner,(Select 'N' from tbl_race_detail R WHERE R.ID = U.ID AND R.Race_date < CURRENT_DATE) status FROM tbl_race_detail U ORDER BY U.ID ASC", conn);
                da.Fill(ds);

                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    RaceDetails RaceDetails = new RaceDetails();
                    RaceDetails.ID = dr["ID"].ToString();
                    RaceDetails.Race_date = Convert.ToDateTime(dr["Race_date"].ToString());
                    RaceDetails.Price = dr["Price"].ToString();
                    RaceDetails.Race_Detail = dr["Race_Detail"].ToString();
                    RaceDetails.Location = dr["Location"].ToString();
                    RaceDetails.Winner = dr["Winner"].ToString();
                    RaceDetails.status = dr["status"].ToString();
                    lstRaceDetails.Add(RaceDetails);
                }
            }
            return View(lstRaceDetails);
        }

        public ActionResult ApplyForRace(string ID)
        {
            int count = 0;
            //string Out = "";
            string UserID = "";
            if (Session["UserID"] != null)
            {
                UserID = Session["UserID"].ToString();
            }
            else
            {
                return RedirectToAction("Login");
            }
            using (MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(Connection))
            {
                MySql.Data.MySqlClient.MySqlCommand cmd2 = new MySql.Data.MySqlClient.MySqlCommand("select Count(*) from tbl_race_participate_det o where o.RacerId = @RacerId and o.RaceId = @RaceId", conn);
                cmd2.Parameters.AddWithValue("@RaceId", ID);
                cmd2.Parameters.AddWithValue("@RacerId", UserID);
                conn.Open();
                count = Convert.ToInt32(cmd2.ExecuteScalar());
                conn.Close();
                if (count > 0)
                {
                    TempData["Msg"] = "Your are Already applied for the race.";
                }
                else
                {               
                    MySql.Data.MySqlClient.MySqlCommand cmd1 = new MySql.Data.MySqlClient.MySqlCommand("insert into tbl_race_participate_det(RacerId, RaceId) Values(@RacerId, @RaceId)", conn);
                    cmd1.Parameters.AddWithValue("@RaceId", ID);
                    cmd1.Parameters.AddWithValue("@RacerId", UserID);
                    conn.Open();
                    count = cmd1.ExecuteNonQuery();
                    conn.Close();
                    if (count == 0)
                    {
                        TempData["Msg"] = "Error While inserting Data."; 
                    }
                    else
                    {
                        //Out = "Y";
                        TempData["Msg"] = "Your are Successfully Applied for the race.";
                    }
                }
            }
            return RedirectToAction("RaceDetails");
        }


        public ActionResult Byke()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Byke(RegistrationDetails obj)
        {
            int count = 0;
            string Out = "";
            string UserID = "";
            if (Session["UserID"] != null)
            {
                UserID = Session["UserID"].ToString();
            }
            else
            {
                return RedirectToAction("Login");
            }
            using (MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(Connection))
            {
                MySql.Data.MySqlClient.MySqlCommand cmd1 = new MySql.Data.MySqlClient.MySqlCommand("Update tbl_racer_details set BYKE = @Bike Where UserID = @ID", conn);
                cmd1.Parameters.AddWithValue("@Bike", obj.Bike);
                cmd1.Parameters.AddWithValue("@ID", UserID);
                conn.Open();
                count = cmd1.ExecuteNonQuery();
                conn.Close();
                if (count == 0)
                {
                    Out = "Error While inserting Data.";
                }
                else
                {
                    Out = "Y";
                }
            }
            return View("Index");
        }


        public ActionResult UpdateWinnerName(string id)
        {
            Session["ABCid"] = id;
            WinnerDetail WinnerDetail = new WinnerDetail();
            List<WinnerList> LSTWinner = new List<WinnerList>();
            DataSet ds = new DataSet("Detail");
            using (MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(Connection))
            {
                MySql.Data.MySqlClient.MySqlDataAdapter da = new MySql.Data.MySqlClient.MySqlDataAdapter("SELECT A.UserID as ID,concat(A.FirstName,' ',A.LastName) as NAME FROM tbl_racer_details A, tbl_race_participate_det B WHERE A.UserID=B.RacerId And B.RaceId=" + id, conn);
                da.Fill(ds);

                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    WinnerList WinnerList = new WinnerList();
                    WinnerList.text = dr["NAME"].ToString();
                    WinnerList.value = dr["NAME"].ToString();
                    LSTWinner.Add(WinnerList);
                }
            }
            WinnerDetail.Winner = LSTWinner;
            return View(WinnerDetail);
        }

        [HttpPost]
        public ActionResult UpdateWinnerName(WinnerDetail WinnerDetail)
        {
            string UserId = "";
            string Out = "";
            int count;
            if (Session["ABCid"] != null)
            {
                UserId = Session["ABCid"].ToString(); 
            }
            else
            {
                return RedirectToAction("Login");
            } 
            using (MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(Connection))
            {
                MySql.Data.MySqlClient.MySqlCommand cmd1 = new MySql.Data.MySqlClient.MySqlCommand("Update tbl_race_detail set Winner = @WinnerName Where id = @UserID", conn);
                
                cmd1.Parameters.AddWithValue("@UserID", UserId);
                cmd1.Parameters.AddWithValue("@WinnerName", WinnerDetail.WinnerName);  
                conn.Open();
                count = cmd1.ExecuteNonQuery();
                conn.Close();
                if (count == 0)
                {
                    Out = "Error While inserting Data.";
                }
                else
                {
                    Out = "Y";
                }
            }
            return RedirectToAction("RaceDetails");
        }
    }
}